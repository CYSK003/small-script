#!/bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin
export PATH

clear
CUR_DIR=$(pwd)

if [ $(id -u) != "0" ]; then
    printf "Error: You must be root to run this script!"
    exit 1
fi

echo "#############################################################"
echo "# A tool to auto-compile & install pureftpd on Linux"
echo "# Env: Debian/Ubuntu"
echo "# Created by WangYan on 2011.04.30"
echo "# Author Url: http://wangyan.org"
echo "# Version: 1.0"
echo "#############################################################"
echo ""

####################### User Custom Options #######################

echo "Please input the IP or domain of server:"
read -p "(e.g: 127.0.0.1):" server_ip
if [ "$server_ip" == "" ]; then
	server_ip="127.0.0.1"
fi
echo "---------------------------"
echo "Server IP = $server_ip"
echo "---------------------------"
echo ""

echo "Please input webroot dir:"
read -p "(Default webroot dir: /var/www):" webroot
if [ "$webroot" == "" ]; then
    webroot="/var/www"
fi
echo "---------------------------"
echo "Webroot dir = $webroot"
echo "---------------------------"
echo ""

echo "Please input the root password of mysql:"
read -p "(Default password: 123456):" mysqlrootpwd
if [ "$mysqlrootpwd" == "" ]; then
	mysqlrootpwd="123456"
fi
echo "---------------------------"
echo "mysqlrootpwd = $mysqlrootpwd"
echo "---------------------------"
echo ""

echo "Please input the ftpuser password of mysql:"
read -p "(Default password: 123456):" ftpsqlpwd
if [ "$ftpsqlpwd" == "" ]; then
	ftpsqlpwd="123456"
fi
echo "---------------------------"
echo "ftpsqlpwd = $ftpsqlpwd"
echo "---------------------------"
echo ""

echo "Please input the admin password of PureFTPd:"
read -p "(Default password: 123456):" ftpadminpwd
if [ "$ftpadminpwd" == "" ]; then
	ftpadminpwd="123456"
fi
echo "---------------------------"
echo "ftpadminpwd = $ftpadminpwd"
echo "---------------------------"


get_char()
{
SAVEDSTTY=`stty -g`
stty -echo
stty cbreak
dd if=/dev/tty bs=1 count=1 2> /dev/null
stty -raw
stty echo
stty $SAVEDSTTY
}
echo ""
echo "Press any key to start install Pure-FTPd..."
char=`get_char`

echo ""
echo "================pureftpd Install==============="

echo "/usr/local/mysql/lib/" >> /etc/ld.so.conf
ldconfig

if [ ! -s pure-ftpd-*.tar.gz ]; then
    wget -c http://wangyan.org/download/lnmp/pure-ftpd-latest.tar.gz
   #wget -c http://download.pureftpd.org/pub/pure-ftpd/releases/pure-ftpd-1.0.29.tar.gz
fi

tar -zxf pure-ftpd-*.tar.gz
cd pure-ftpd-*/

./configure --prefix=/usr/local/pureftpd CFLAGS=-O2 \
--with-mysql=/usr/local/mysql \
--with-altlog \
--with-cookie \
--with-diraliases \
--with-ftpwho \
--with-language=simplified-chinese \
--with-paranoidmsg \
--with-peruserlimits \
--with-quotas \
--with-ratios \
--with-sysquotas \
--with-throttling \
--with-virtualchroot \
--with-virtualhosts \
--with-welcomemsg
make && make install

cp configuration-file/pure-config.pl /usr/local/pureftpd/sbin/pure-config.pl
chmod 755 /usr/local/pureftpd/sbin/pure-config.pl
mkdir /usr/local/pureftpd/conf/
cp $CUR_DIR/conf/pure-ftpd.conf /usr/local/pureftpd/conf/pure-ftpd.conf
cp $CUR_DIR/conf/pureftpd-mysql.conf /usr/local/pureftpd/conf/pureftpd-mysql.conf
sed -i 's/ftpsqlpwd/'$ftpsqlpwd'/g' /usr/local/pureftpd/conf/pureftpd-mysql.conf

cp $CUR_DIR/conf/script.mysql /tmp/script.mysql
sed -i 's/ftpsqlpwd/'$ftpsqlpwd'/g' /tmp/script.mysql
sed -i 's/ftpadminpwd/'$ftpadminpwd'/g' /tmp/script.mysql
mysql -u root -p$mysqlrootpwd -h 127.0.0.1 < /tmp/script.mysql


echo "================User manager for PureFTPd==============="

cd $CUR_DIR

if [ ! -s pure-ftpd-*.tar.gz ]; then
    wget -c http://wangyan.org/download/lnmp/ftp_latest.tar.gz
   #wget -c http://machiel.generaal.net/files/pureftpd/ftp_v2.1.tar.gz
fi

tar -zxf ftp_*.tar.gz
mv $CUR_DIR/ftp $webroot
cp $CUR_DIR/conf/config.php $webroot/ftp/config.php
sed -i 's/ftpsqlpwd/'$ftpsqlpwd'/g' $webroot/ftp/config.php
sed -i 's/server_ip/'$server_ip'/g' $webroot/ftp/config.php

cp $CUR_DIR/conf/pureftpd /etc/init.d/pureftpd
chmod 755 /etc/init.d/pureftpd
update-rc.d pureftpd defaults

/etc/init.d/pureftpd start

clear
echo ""
echo "===================== Install completed ====================="
echo ""
echo "Install PureFTPD V1.0 completed!"
echo "For more information please visit http://wangyan.org/pureftpd.html"
echo ""
echo "Ftp web dir: $webroot/ftp"
echo "Ftpuser password of mysql: $ftpsqlpwd"
echo "Admin password of pureftpd: $ftpadminpwd"
echo "Pureftpd log dir: /var/log/pureftpd.log"
echo "Pureftpd config dir: /usr/local/pureftpd/conf/pure-ftpd.conf"
echo ""
echo "Usage: /etc/init.d/pureftpd {start|stop|restart|status}"
echo ""
echo "============================================================="
echo ""

