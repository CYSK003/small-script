一、简介

1、该一键安装包是一个Shell脚本，用于一键安装PureFTPd及web管理界面。
2、适用于Debian/Ubuntu系统，且通过 Linode 上测试。
3、可自动下载最新版本的PureFTPd编译安装，不需要人为更新。
4、支持MySQL用户，可设置相关权限及密码。
5、可修改此脚本的编译参数，这不会对安装造成错误。

二、安装步骤

wget -c http://small-script.googlecode.com/files/pureftpd-1.0.tar.gz
tar -zxf pureftpd-1.0.tar.gz
cd pureftpd-1.0
./install.sh


1、输入服务器IP或者域名
2、网站目根目录
3、MySQL Root 用户密码
4、MySQL ftpuser 用户密码，该用户是专门用来管理 PureFTPd 的。（该密码不需要你记住）
5、administartor 用户密码，该密码是Web管理界面管理员帐号密码。

被动模式端口是 “30000-50000”，加载了防火墙的服务器需要打开。
更多配置选项，请修改/usr/local/pureftpd/conf/pure-ftpd.conf文件。

图文安装教程：https://wangyan.org/blog/pureftpd-install-script.html