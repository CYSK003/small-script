#!/bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin
export PATH

clear
CUR_DIR=$(pwd)

if [ $(id -u) != "0" ]; then
    printf "Error: You must be root to run this script!"
    exit 1
fi

echo "#############################################################"
echo "# A tool to auto-compile & install pureftpd on Linux"
echo "# Env: Debian/Ubuntu/CentOS"
echo "# Created by WangYan on 2011.04.30"
echo "# Author Url: http://wangyan.org"
echo "# Version: 1.2"
echo "#############################################################"
echo ""

####################### User Custom Options #######################

echo "Please input the IP or domain of server:"
read -p "(e.g: 192.168.1.129):" SERVER_IP
if [ -z $SERVER_IP ]; then
    SERVER_IP="192.168.1.129"
fi
echo "---------------------------"
echo "Server IP = $SERVER_IP"
echo "---------------------------"
echo ""

echo "Please input webroot dir:"
read -p "(Default webroot dir: /var/www):" WEBROOT
if [ -z $WEBROOT ]; then
    WEBROOT="/var/www"
fi
echo "---------------------------"
echo "Webroot dir = $WEBROOT"
echo "---------------------------"
echo ""

echo "Please input the root password of mysql:"
read -p "(Default password: 123456):" MYSQLROOTPWD
if [ -z $MYSQLROOTPWD ]; then
	MYSQLROOTPWD="123456"
fi
echo "---------------------------"
echo "MYSQLROOTPWD = $MYSQLROOTPWD"
echo "---------------------------"
echo ""

echo "Please input the ftpuser password of mysql:"
read -p "(Default password: 123456):" FTPSQLPWD
if [ -z $FTPSQLPWD ]; then
	FTPSQLPWD="123456"
fi
echo "---------------------------"
echo "FTPSQLPWD = $FTPSQLPWD"
echo "---------------------------"
echo ""

echo "Please input the admin password of PureFTPd:"
read -p "(Default password: 123456):" FTPADMINPWD
if [ -z $FTPADMINPWD ]; then
	FTPADMINPWD="123456"
fi
echo "---------------------------"
echo "FTPADMINPWD = $FTPADMINPWD"
echo "---------------------------"

get_char()
{
SAVEDSTTY=`stty -g`
stty -echo
stty cbreak
dd if=/dev/tty bs=1 count=1 2> /dev/null
stty -raw
stty echo
stty $SAVEDSTTY
}
echo ""
echo "Press any key to start install Pure-FTPd..."
char=`get_char`

echo ""
echo "================Pureftpd Install==============="

echo "/usr/local/mysql/lib/" >> /etc/ld.so.conf
ldconfig

if [ ! -s pure-ftpd-*.tar.gz ]; then
   wget -c http://download.pureftpd.org/pub/pure-ftpd/releases/pure-ftpd-1.0.32.tar.gz
fi

tar -zxf pure-ftpd-*.tar.gz
cd pure-ftpd-*/

./configure --prefix=/usr/local/pureftpd CFLAGS=-O2 \
--with-mysql=/usr/local/mysql \
--with-altlog \
--with-cookie \
--with-diraliases \
--with-ftpwho \
--with-language=simplified-chinese \
--with-paranoidmsg \
--with-peruserlimits \
--with-quotas \
--with-ratios \
--with-sysquotas \
--with-throttling \
--with-virtualchroot \
--with-virtualhosts \
--with-welcomemsg
make && make install

cp configuration-file/pure-config.pl /usr/local/pureftpd/sbin/pure-config.pl
chmod 755 /usr/local/pureftpd/sbin/pure-config.pl
mkdir /usr/local/pureftpd/conf/
cp $CUR_DIR/conf/pure-ftpd.conf /usr/local/pureftpd/conf/pure-ftpd.conf
cp $CUR_DIR/conf/pureftpd-mysql.conf /usr/local/pureftpd/conf/pureftpd-mysql.conf
sed -i 's/ftpsqlpwd/'$FTPSQLPWD'/g' /usr/local/pureftpd/conf/pureftpd-mysql.conf

cp $CUR_DIR/conf/script.mysql /tmp/script.mysql
sed -i 's/ftpsqlpwd/'$FTPSQLPWD'/g' /tmp/script.mysql
sed -i 's/ftpadminpwd/'$FTPADMINPWD'/g' /tmp/script.mysql
mysql -u root -p$MYSQLROOTPWD -h 127.0.0.1 < /tmp/script.mysql

echo "================User manager for PureFTPd==============="

cd $CUR_DIR

if [ ! -s pure-ftpd-*.tar.gz ]; then
   wget -c http://machiel.generaal.net/files/pureftpd/ftp_v2.1.tar.gz
fi

tar -zxf ftp_*.tar.gz
mv $CUR_DIR/ftp $WEBROOT
cp $CUR_DIR/conf/config.php $WEBROOT/ftp/config.php
sed -i 's/ftpsqlpwd/'$FTPSQLPWD'/g' $WEBROOT/ftp/config.php
sed -i 's/server_ip/'$SERVER_IP'/g' $WEBROOT/ftp/config.php

cp $CUR_DIR/conf/init.d.pure-ftpd /etc/init.d/pure-ftpd
chmod 755 /etc/init.d/pure-ftpd

uname=`lsb_release -i | awk -F: '{print $NF}'`

if [ $uname = "CentOS" ];then
    chkconfig --level 345 pure-ftpd on
else
    update-rc.d pure-ftpd defaults
fi

/etc/init.d/pure-ftpd start

clear
echo ""
echo "===================== Install completed ====================="
echo ""
echo "Install PureFTPD V1.2 completed!"
echo "For more information please visit http://wangyan.org/pureftpd.html"
echo ""
echo "Ftp web dir: $WEBROOT/ftp"
echo "Ftpuser password of mysql: $FTPSQLPWD"
echo "Admin password of pureftpd: $FTPADMINPWD"
echo "Pureftpd log dir: /var/log/pureftpd.log"
echo "Pureftpd config dir: /usr/local/pureftpd/conf/pure-ftpd.conf"
echo ""
echo "Usage: /etc/init.d/pure-ftpd {start|stop|restart|status}"
echo ""
echo "============================================================="
echo ""

